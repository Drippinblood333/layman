from __future__ import annotations

import asyncio
import json
import os
import secrets
import time
import uuid
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse

from .classify import classify_task
from .config import load_config
from .models import RouteDecision, RouterConfig, RouteTier, TaskFeatures, UsageRecord
from .provider import StreamHandle, UpstreamProvider
from .routing import apply_route, decide_route, explicit_model_decision, fallback_decision
from .streaming import SSECapture
from .telemetry import UsageStore, estimate_cost, extract_usage, price_for_model
from .validation import validate_response


RETRYABLE_STATUS = {429, 500, 502, 503, 504}
LOOPBACK_HOSTS = {"127.0.0.1", "::1", "localhost", "testclient"}
ASSET_ROOT = Path(__file__).with_name("dashboard")


def _require_admin(request: Request, settings: RouterConfig) -> None:
    host = request.client.host if request.client else ""
    if host not in LOOPBACK_HOSTS and not settings.admin_allow_non_loopback:
        raise HTTPException(status_code=403, detail="Admin endpoint is loopback-only")
    expected = os.getenv(settings.admin_token_env)
    supplied = request.headers.get("x-layman-admin-token")
    if not expected:
        raise HTTPException(status_code=503, detail=f"Set {settings.admin_token_env} before using admin endpoints")
    if not supplied or not secrets.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Invalid admin token")


def _layman_headers(request_id: str, decision: RouteDecision, fallback_used: bool) -> dict[str, str]:
    return {
        "x-layman-request-id": request_id,
        "x-layman-route-tier": decision.route_tier.value,
        "x-layman-selected-model": decision.selected_model,
        "x-layman-fallback-used": str(fallback_used).lower(),
    }


def _usage_record(
    *,
    request_id: str,
    features: TaskFeatures,
    decision: RouteDecision,
    config: RouterConfig,
    response: dict[str, Any] | None,
    latency_ms: int,
    fallback_used: bool,
    validator_passed: bool | None,
    error_category: str | None,
    upstream_request_id: str | None,
) -> UsageRecord:
    usage = extract_usage(response)
    pricing = price_for_model(config, decision.selected_model)
    actual = estimate_cost(usage, pricing) if pricing else 0.0
    baseline = estimate_cost(usage, config.tiers[RouteTier.DEEP].pricing)
    return UsageRecord(
        request_id=request_id,
        project_id=features.project_id,
        prompt_hash=features.prompt_hash,
        task_type=features.task_type.value,
        complexity=features.complexity,
        risk=features.risk,
        route_tier=decision.route_tier.value,
        selected_model=decision.selected_model,
        reasoning_effort=decision.reasoning_effort,
        route_reason=decision.route_reason,
        **usage,
        latency_ms=latency_ms,
        estimated_cost_usd=actual,
        estimated_always_deep_cost_usd=baseline,
        fallback_used=fallback_used,
        validator_passed=validator_passed,
        error_category=error_category,
        upstream_request_id=upstream_request_id,
        metadata={"price_version": config.price_version, "automatic": decision.automatic, "cost_estimate_available": pricing is not None},
    )


def create_app(
    config: RouterConfig | None = None,
    *,
    transport: httpx.AsyncBaseTransport | None = None,
) -> FastAPI:
    settings = config or load_config()
    store = UsageStore(settings.database_path, settings)
    store.initialize()
    store.prune()
    provider = UpstreamProvider(settings.upstream_base_url, transport=transport, timeout_seconds=settings.upstream_timeout_seconds)
    app = FastAPI(title="Layman Router", version="0.3.0", docs_url=None, redoc_url=None)
    app.state.config = settings
    app.state.store = store
    app.state.provider = provider

    @app.get("/healthz")
    async def health() -> dict[str, Any]:
        return {
            "status": "ok" if store.healthy() else "degraded",
            "database": "ok" if store.healthy() else "error",
            "price_version": settings.price_version,
            "tiers": {tier.value: spec.model for tier, spec in settings.tiers.items()},
            "dashboard": "/admin/" if settings.dashboard_enabled else None,
            "demo_mode": settings.demo_mode,
        }

    @app.get("/admin", include_in_schema=False)
    async def admin_redirect() -> Response:
        if not settings.dashboard_enabled:
            raise HTTPException(status_code=404)
        return RedirectResponse("/admin/")

    @app.get("/admin/", include_in_schema=False)
    async def admin_dashboard() -> Response:
        if not settings.dashboard_enabled:
            raise HTTPException(status_code=404)
        return HTMLResponse(
            (ASSET_ROOT / "index.html").read_text(encoding="utf-8"),
            headers={
                "cache-control": "no-store",
                "content-security-policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
                "x-content-type-options": "nosniff",
                "x-frame-options": "DENY",
                "referrer-policy": "no-referrer",
            },
        )

    @app.get("/admin/assets/{name}", include_in_schema=False)
    async def admin_asset(name: str) -> Response:
        if not settings.dashboard_enabled or name not in {"dashboard.css", "dashboard.js"}:
            raise HTTPException(status_code=404)
        return FileResponse(ASSET_ROOT / name, headers={"cache-control": "no-store", "x-content-type-options": "nosniff"})

    @app.get("/v1/models")
    async def models() -> dict[str, Any]:
        created = int(time.time())
        ids = ["auto", *dict.fromkeys(spec.model for spec in settings.tiers.values())]
        return {"object": "list", "data": [{"id": item, "object": "model", "created": created, "owned_by": "layman-router"} for item in ids]}

    @app.get("/admin/usage/summary")
    async def usage_summary(
        request: Request,
        project_id: str | None = None,
        start: str | None = Query(default=None, alias="from"),
        end: str | None = Query(default=None, alias="to"),
    ) -> dict[str, Any]:
        _require_admin(request, settings)
        return await asyncio.to_thread(store.summary, project_id=project_id, start=start, end=end)

    @app.get("/admin/usage/recent")
    async def usage_recent(request: Request, limit: int = 50, project_id: str | None = None) -> dict[str, Any]:
        _require_admin(request, settings)
        return {"requests": await asyncio.to_thread(store.recent, limit=limit, project_id=project_id)}

    @app.get("/admin/routing/analysis")
    async def routing_analysis(request: Request) -> dict[str, Any]:
        _require_admin(request, settings)
        return await asyncio.to_thread(store.routing_analysis)

    @app.post("/v1/responses")
    async def responses(request: Request) -> Response:
        if settings.demo_mode:
            raise HTTPException(status_code=403, detail="Responses forwarding is disabled in synthetic demo mode")
        try:
            payload = await request.json()
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Request body must be valid JSON") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("model"), str):
            raise HTTPException(status_code=400, detail="Request must contain a string model")
        if not request.headers.get("authorization"):
            raise HTTPException(status_code=401, detail="Authorization header is required")

        features = classify_task(payload, settings)
        metadata = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        decision = decide_route(features, settings, metadata) if payload["model"] == "auto" else explicit_model_decision(payload, settings)
        headers = provider.request_headers(request.headers)
        request_id = str(uuid.uuid4())
        started = time.perf_counter()

        if payload.get("stream") is True:
            return await _stream_response(
                provider=provider,
                store=store,
                config=settings,
                payload=payload,
                headers=headers,
                features=features,
                decision=decision,
                request_id=request_id,
                started=started,
            )
        return await _nonstream_response(
            provider=provider,
            store=store,
            config=settings,
            payload=payload,
            headers=headers,
            features=features,
            decision=decision,
            request_id=request_id,
            started=started,
        )

    return app


async def _nonstream_response(
    *, provider: UpstreamProvider, store: UsageStore, config: RouterConfig, payload: dict[str, Any],
    headers: dict[str, str], features: TaskFeatures, decision: RouteDecision, request_id: str, started: float,
) -> Response:
    current = decision
    fallback_used = False
    error_category: str | None = None
    upstream: httpx.Response | None = None
    data: dict[str, Any] | None = None
    validation_passed: bool | None = None

    for attempt in range(2):
        routed = apply_route(payload, current)
        try:
            upstream = await provider.post(routed, headers)
        except httpx.HTTPError:
            error_category = "upstream_network_error"
            fallback = fallback_decision(current, config) if attempt == 0 else None
            if fallback:
                current, fallback_used = fallback, True
                continue
            break
        if upstream.status_code in RETRYABLE_STATUS:
            error_category = f"upstream_http_{upstream.status_code}"
            fallback = fallback_decision(current, config) if attempt == 0 else None
            if fallback:
                current, fallback_used = fallback, True
                continue
        try:
            parsed = upstream.json()
            data = parsed if isinstance(parsed, dict) else None
        except json.JSONDecodeError:
            data = None
        if upstream.is_success and data is not None:
            validation = validate_response(data, routed)
            validation_passed = validation.passed
            if not validation.passed:
                error_category = validation.reason
                fallback = fallback_decision(current, config) if attempt == 0 else None
                if fallback:
                    current, fallback_used = fallback, True
                    continue
        break

    latency_ms = int((time.perf_counter() - started) * 1000)
    upstream_id = upstream.headers.get("openai-request-id") if upstream else None
    record = _usage_record(
        request_id=request_id, features=features, decision=current, config=config, response=data,
        latency_ms=latency_ms, fallback_used=fallback_used, validator_passed=validation_passed,
        error_category=error_category, upstream_request_id=upstream_id,
    )
    await asyncio.to_thread(store.add, record)
    if upstream is None:
        return JSONResponse(status_code=502, headers=_layman_headers(request_id, current, fallback_used), content={"error": {"message": "Upstream request failed", "type": "layman_router_error"}})
    response_headers = provider.response_headers(upstream.headers)
    response_headers.update(_layman_headers(request_id, current, fallback_used))
    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        headers=response_headers,
        media_type=upstream.headers.get("content-type", "application/json").split(";", 1)[0],
    )


async def _stream_response(
    *, provider: UpstreamProvider, store: UsageStore, config: RouterConfig, payload: dict[str, Any],
    headers: dict[str, str], features: TaskFeatures, decision: RouteDecision, request_id: str, started: float,
) -> Response:
    current = decision
    fallback_used = False
    handle: StreamHandle | None = None
    error_category: str | None = None

    for attempt in range(2):
        routed = apply_route(payload, current)
        try:
            handle = await provider.stream(routed, headers)
        except httpx.HTTPError:
            error_category = "upstream_network_error"
            fallback = fallback_decision(current, config) if attempt == 0 else None
            if fallback:
                current, fallback_used = fallback, True
                continue
            break
        if handle.response.status_code in RETRYABLE_STATUS or (handle.response.is_success and not handle.first_chunk):
            error_category = f"upstream_http_{handle.response.status_code}" if handle.response.status_code in RETRYABLE_STATUS else "empty_stream"
            fallback = fallback_decision(current, config) if attempt == 0 else None
            if fallback:
                await handle.close()
                handle = None
                current, fallback_used = fallback, True
                continue
        break

    if handle is None:
        record = _usage_record(
            request_id=request_id, features=features, decision=current, config=config, response=None,
            latency_ms=int((time.perf_counter() - started) * 1000), fallback_used=fallback_used,
            validator_passed=None, error_category=error_category, upstream_request_id=None,
        )
        await asyncio.to_thread(store.add, record)
        return JSONResponse(status_code=502, headers=_layman_headers(request_id, current, fallback_used), content={"error": {"message": "Upstream stream failed before first event", "type": "layman_router_error"}})

    if not handle.response.is_success:
        body = handle.first_chunk + await handle.response.aread()
        status = handle.response.status_code
        response_headers = provider.response_headers(handle.response.headers)
        response_headers.update(_layman_headers(request_id, current, fallback_used))
        await handle.close()
        record = _usage_record(
            request_id=request_id, features=features, decision=current, config=config, response=None,
            latency_ms=int((time.perf_counter() - started) * 1000), fallback_used=fallback_used,
            validator_passed=None, error_category=error_category or f"upstream_http_{status}",
            upstream_request_id=response_headers.get("openai-request-id"),
        )
        await asyncio.to_thread(store.add, record)
        return Response(content=body, status_code=status, headers=response_headers)

    capture = SSECapture()
    upstream_id = handle.response.headers.get("openai-request-id")

    async def body() -> Any:
        stream_error: str | None = None
        try:
            capture.feed(handle.first_chunk)
            yield handle.first_chunk
            async for chunk in handle.iterator:
                capture.feed(chunk)
                yield chunk
        except httpx.HTTPError as exc:
            stream_error = "stream_interrupted_after_first_event"
            error = json.dumps({"type": "error", "error": {"type": "layman_router_stream_error", "message": str(exc)}})
            yield f"event: error\ndata: {error}\n\n".encode("utf-8")
        finally:
            await handle.close()
            terminal = capture.completed_response
            validator = None if terminal is None else terminal.get("status") == "completed"
            record = _usage_record(
                request_id=request_id, features=features, decision=current, config=config, response=terminal,
                latency_ms=int((time.perf_counter() - started) * 1000), fallback_used=fallback_used,
                validator_passed=validator, error_category=stream_error or error_category,
                upstream_request_id=upstream_id,
            )
            await asyncio.to_thread(store.add, record)

    response_headers = provider.response_headers(handle.response.headers)
    response_headers.update(_layman_headers(request_id, current, fallback_used))
    return StreamingResponse(body(), status_code=200, headers=response_headers, media_type="text/event-stream")


app = create_app()
