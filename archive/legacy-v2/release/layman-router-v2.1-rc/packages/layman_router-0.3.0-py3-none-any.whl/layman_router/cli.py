from __future__ import annotations

import argparse
import http.client
import json
import os
import secrets
import sys
import tempfile
from pathlib import Path

import uvicorn

from .codex_config import disable_codex, enable_codex, list_backups, restore_backup
from .config import load_config


def _fetch(path: str, *, admin: bool = False) -> dict:
    config = load_config()
    headers = {}
    if admin:
        token = os.getenv(config.admin_token_env)
        if not token:
            raise RuntimeError(f"Set {config.admin_token_env} before requesting reports")
        headers["X-Layman-Admin-Token"] = token
    if config.listen_host not in {"127.0.0.1", "::1", "localhost"}:
        raise RuntimeError("CLI status and report requests require a loopback listen_host")
    connection = http.client.HTTPConnection(config.listen_host, config.listen_port, timeout=5)
    try:
        connection.request("GET", path, headers=headers)
        response = connection.getresponse()
        if response.status >= 400:
            raise RuntimeError(f"Router returned HTTP {response.status}")
        return json.load(response)
    finally:
        connection.close()


def _writable_ancestor(path: str) -> bool:
    candidate = Path(path).expanduser().resolve().parent
    while not candidate.exists() and candidate != candidate.parent:
        candidate = candidate.parent
    return candidate.is_dir() and os.access(candidate, os.W_OK)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="layman-router")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("serve", help="Run the local router")
    commands.add_parser("status", help="Check router health")
    commands.add_parser("doctor", help="Check configuration, credentials, database, and service health")
    commands.add_parser("admin-token", help="Generate a new local dashboard token")
    demo = commands.add_parser("demo", help="Run an offline dashboard with clearly marked synthetic telemetry")
    demo.add_argument("--port", type=int, default=8788)
    report = commands.add_parser("report", help="Show the local usage summary")
    report.add_argument("--project-id")
    codex = commands.add_parser("codex", help="Manage Codex provider configuration")
    codex_commands = codex.add_subparsers(dest="codex_command", required=True)
    for name in ("enable", "disable"):
        command = codex_commands.add_parser(name)
        mode = command.add_mutually_exclusive_group()
        mode.add_argument("--dry-run", action="store_true", default=True)
        mode.add_argument("--apply", action="store_true")
    codex_commands.add_parser("backups", help="List Layman Router Codex config backups")
    restore = codex_commands.add_parser("restore", help="Restore a selected Layman Router backup")
    restore.add_argument("backup")
    restore_mode = restore.add_mutually_exclusive_group()
    restore_mode.add_argument("--dry-run", action="store_true", default=True)
    restore_mode.add_argument("--apply", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "serve":
            config = load_config()
            uvicorn.run("layman_router.app:create_app", factory=True, host=config.listen_host, port=config.listen_port)
            return 0
        if args.command == "status":
            print(json.dumps(_fetch("/healthz"), indent=2, ensure_ascii=False))
            return 0
        if args.command == "doctor":
            config = load_config()
            checks = {
                "config": "ok",
                "listen_is_loopback": config.listen_host in {"127.0.0.1", "::1", "localhost"},
                "openai_api_key": "set" if os.getenv("OPENAI_API_KEY") else "missing",
                "admin_token": "set" if os.getenv(config.admin_token_env) else "missing",
                "database_parent_writable": _writable_ancestor(config.database_path),
            }
            try:
                checks["service"] = _fetch("/healthz").get("status", "unknown")
            except (OSError, RuntimeError, TimeoutError):
                checks["service"] = "offline"
            print(json.dumps(checks, indent=2, ensure_ascii=False))
            return 0 if checks["listen_is_loopback"] and checks["database_parent_writable"] else 1
        if args.command == "admin-token":
            print(secrets.token_urlsafe(32))
            print("Set this value as LAYMAN_ROUTER_ADMIN_TOKEN in the router process.", file=sys.stderr)
            return 0
        if args.command == "demo":
            from .demo import seed_demo
            from .telemetry import UsageStore

            with tempfile.TemporaryDirectory(prefix="layman-router-demo-") as directory:
                os.environ["LAYMAN_ROUTER_DEMO"] = "true"
                os.environ["LAYMAN_ROUTER_PORT"] = str(args.port)
                os.environ["LAYMAN_ROUTER_DATABASE_PATH"] = str(Path(directory) / "demo.sqlite3")
                token = secrets.token_urlsafe(18)
                config = load_config()
                os.environ[config.admin_token_env] = token
                store = UsageStore(config.database_path, config)
                store.initialize()
                seed_demo(store, config)
                print(f"Dashboard: http://127.0.0.1:{args.port}/admin/")
                print(f"Temporary demo token: {token}")
                print("Synthetic data is deleted when the demo process exits.")
                uvicorn.run("layman_router.app:create_app", factory=True, host="127.0.0.1", port=args.port)
            return 0
        if args.command == "report":
            query = f"?project_id={args.project_id}" if args.project_id else ""
            print(json.dumps(_fetch(f"/admin/usage/summary{query}", admin=True), indent=2, ensure_ascii=False))
            return 0
        if args.command == "codex":
            if args.codex_command == "backups":
                backups = list_backups()
                print("\n".join(str(path) for path in backups) if backups else "No Layman Router backups found.")
                return 0
            if args.codex_command == "restore":
                change = restore_backup(args.backup, apply=args.apply)
            else:
                change = enable_codex(apply=args.apply) if args.codex_command == "enable" else disable_codex(apply=args.apply)
            print(change.diff or "No configuration changes required.")
            for conflict in change.conflicts:
                print(f"warning: {conflict}", file=sys.stderr)
            if args.apply:
                print(f"Updated: {change.config_path}")
                if change.backup_path:
                    print(f"Backup: {change.backup_path}")
            else:
                print("Dry run only. Re-run with --apply to write this change.")
            return 0
    except (RuntimeError, ValueError, FileNotFoundError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
