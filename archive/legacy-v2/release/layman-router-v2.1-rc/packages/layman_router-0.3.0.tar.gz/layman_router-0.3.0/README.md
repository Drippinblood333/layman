# Layman Router v2 · Release Candidate

Layman Router is a local OpenAI-compatible Responses API proxy for Codex. Requests with `model="auto"` are classified and routed to configurable fast, balanced, or deep model tiers. Explicit model names pass through unchanged.

The router does not store prompt, code, instructions, tool arguments, API keys, or response text. SQLite telemetry contains only a SHA-256 request hash, routing features, usage, latency, cost estimates, and error categories.

The local management interface is available at `http://127.0.0.1:8787/admin/`. Its data endpoints require `LAYMAN_ROUTER_ADMIN_TOKEN`; the browser retains that token only for the current tab.

## Install and run

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -e ".\services\layman-router[dev]"
$env:OPENAI_API_KEY = "your-api-key"
$env:LAYMAN_ROUTER_ADMIN_TOKEN = "choose-a-local-admin-token"
.\.venv\Scripts\layman-router serve
```

The default listener is `127.0.0.1:8787`. Check it with `.\.venv\Scripts\layman-router status`. Run `.\.venv\Scripts\layman-router doctor` to check the installation without printing secrets.

## Configure Codex safely

Preview the user-level `config.toml` change first:

```powershell
.\.venv\Scripts\layman-router codex enable --dry-run
```

Apply only after reviewing the diff:

```powershell
.\.venv\Scripts\layman-router codex enable --apply
```

The command creates a timestamped backup and records only the values needed for a later restore. Disable with `.\.venv\Scripts\layman-router codex disable --apply`. If a later user edit conflicts, disable leaves it untouched; use `codex backups` and `codex restore` for explicit recovery.

## Direct API

```bash
curl http://127.0.0.1:8787/v1/responses \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"auto","input":"Summarize this change","metadata":{"layman_project_id":"default"}}'
```

Recognized metadata overrides are `layman_project_id`, `layman_quality`, `layman_budget`, and `layman_route`. Project defaults and model prices live in `config/projects.yaml`.

## Usage report and tests

Run `.\.venv\Scripts\layman-router report` after setting the local admin token. `estimated_savings` re-prices observed tokens at the deep-tier rate; it is counterfactual, not measured savings.

```powershell
.\.venv\Scripts\python -m pytest .\services\layman-router
```

The tests use an in-process mock upstream and never call OpenAI.

Product documentation: [installation](../../docs/INSTALL.md), [recovery](../../docs/RECOVERY.md), [security](../../docs/SECURITY.md), [benchmarks](../../docs/BENCHMARKS.md), and [release procedure](../../docs/RELEASE.md).
